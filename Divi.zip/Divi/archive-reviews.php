<?php get_header(); ?>

<div id="main-content" class="blog_post_layout birdcode-ticket">
	<div class="container">
		<div id="content-area" class="clearfix">
			<div id="left-area" style="float: left;">
            <div id="post" class="reviews_list">
	           <script type="text/javascript" src="https://birdeye.com/embed/v4/151275155374091/3/260380515"></script><div id="bf-revz-widget-260380515" style="-webkit-overflow-scrolling:touch;"><div class="bf-dv"><span class="bf-spn">provided by <a class="bf-pro" href="http://www.netembark.com" target="_blank">NetEmbark</a> | powered by <a class="bf-pwr" href="https://birdeye.com" target="_blank">BirdEye</a></span></div></div>
				</div> <!-- .link_glossary -->
                
            </div> <!-- #left-area -->
            <div class="glosry-sidbr">
                <?php get_sidebar(); ?>
            </div>
		</div> <!-- #content-area -->
	</div> <!-- .container -->
</div> <!-- #main-content -->

<?php get_footer(); ?>