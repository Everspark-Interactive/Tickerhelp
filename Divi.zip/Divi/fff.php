<?php

/*
Template Name: FFQArr
*/
get_header(); ?>


<!--faq start-->
<div class="faq-wrap">
  <div class="container">
    <h3>OUR PROMISES TO YOUww</h3>
    <div class="faqs">
      <div class="collaps">
        <div class="row">
          <div class="col-md-6">
            <ul class="faqs-service faqs-service-left">
              <li>
                <h4 class="">WE WILL GIVE YOU TIME111</h4>
                <p style="display: none;">We win cases when other lawyers can’t, because we spend every minute, every day, every week, working on your case. When defense and insurance lawyers are working on other cases, in meetings, or on vacations, we are working on your case. Your case is our full time job, so you can worry about recovering from your injury and other important things in your life.</p>
                <div class="clearfix"></div>
              </li>
              <li>
                <h4 class="">WE WILL GIVE YOU TIME</h4>
                <p style="display: none;">We win cases when other lawyers can’t, because we spend every minute, every day, every week, working on your case. When defense and insurance lawyers are working on other cases, in meetings, or on vacations, we are working on your case. Your case is our full time job, so you can worry about recovering from your injury and other important things in your life.</p>
                <div class="clearfix"></div>
              </li>
              <li>
                <h4 class="">WE WILL GIVE YOU TIME</h4>
                <p style="display: none;">We win cases when other lawyers can’t, because we spend every minute, every day, every week, working on your case. When defense and insurance lawyers are working on other cases, in meetings, or on vacations, we are working on your case. Your case is our full time job, so you can worry about recovering from your injury and other important things in your life.</p>
                <div class="clearfix"></div>
              </li>
              <li>
                <h4 class="">WE WILL GIVE YOU TIME</h4>
                <p style="display: none;">We win cases when other lawyers can’t, because we spend every minute, every day, every week, working on your case. When defense and insurance lawyers are working on other cases, in meetings, or on vacations, we are working on your case. Your case is our full time job, so you can worry about recovering from your injury and other important things in your life.</p>
                <div class="clearfix"></div>
              </li>
              <li>
                <h4 class="">WE WILL GIVE YOU TIME</h4>
                <p style="display: none;">We win cases when other lawyers can’t, because we spend every minute, every day, every week, working on your case. When defense and insurance lawyers are working on other cases, in meetings, or on vacations, we are working on your case. Your case is our full time job, so you can worry about recovering from your injury and other important things in your life.</p>
                <div class="clearfix"></div>
              </li>
            </ul>
          </div>
          <div class="col-md-6">
            <ul class="faqs-service faqs-service-left">
              <li>
                <h4 class="">WE WILL GIVE YOU TIME</h4>
                <p style="display: none;">We win cases when other lawyers can’t, because we spend every minute, every day, every week, working on your case. When defense and insurance lawyers are working on other cases, in meetings, or on vacations, we are working on your case. Your case is our full time job, so you can worry about recovering from your injury and other important things in your life.</p>
                <div class="clearfix"></div>
              </li>
              <li>
                <h4 class="">WE WILL GIVE YOU TIME</h4>
                <p style="display: none;">We win cases when other lawyers can’t, because we spend every minute, every day, every week, working on your case. When defense and insurance lawyers are working on other cases, in meetings, or on vacations, we are working on your case. Your case is our full time job, so you can worry about recovering from your injury and other important things in your life.</p>
                <div class="clearfix"></div>
              </li>
              <li>
                <h4 class="">WE WILL GIVE YOU TIME</h4>
                <p style="display: none;">We win cases when other lawyers can’t, because we spend every minute, every day, every week, working on your case. When defense and insurance lawyers are working on other cases, in meetings, or on vacations, we are working on your case. Your case is our full time job, so you can worry about recovering from your injury and other important things in your life.</p>
                <div class="clearfix"></div>
              </li>
              <li>
                <h4 class="">WE WILL GIVE YOU TIME</h4>
                <p style="display: none;">We win cases when other lawyers can’t, because we spend every minute, every day, every week, working on your case. When defense and insurance lawyers are working on other cases, in meetings, or on vacations, we are working on your case. Your case is our full time job, so you can worry about recovering from your injury and other important things in your life.</p>
                <div class="clearfix"></div>
              </li>
              <li>
                <h4 class="">WE WILL GIVE YOU TIME</h4>
                <p style="display: none;">We win cases when other lawyers can’t, because we spend every minute, every day, every week, working on your case. When defense and insurance lawyers are working on other cases, in meetings, or on vacations, we are working on your case. Your case is our full time job, so you can worry about recovering from your injury and other important things in your life.</p>
                <div class="clearfix"></div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--faq end--> 

<?php get_footer(); ?>
