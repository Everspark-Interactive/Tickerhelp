<?php 

get_header(); 

if($_SERVER['REMOTE_ADDR']=='182.191.122.89'){
    if(get_the_ID()==5427){
    	echo 'OKKK--=====';exit;
    }
}


$is_page_builder_used = et_pb_is_pagebuilder_used( get_the_ID() );

?>


<?php if(is_page(5427) || is_page(6457) || is_page(6454)){ ?>


<style type="text/css">
@media screen and (min-width: 767px){ 
div#left-area {
    width: 70% !important;
}
div#sidebar {
    width: 28% !important;
}
.et_right_sidebar #main-content .container:before {
    right: 29% !important;
}
input#gform_submit_button_1 {
    margin-left: 17px;
    width: 95% !important;
}
}
@media screen and (max-width: 767px){ 
#custom_html-2 .testbar_22 iframe {
    transform: scale(0.9) !important;
    transform-origin: 0 0 !important;
}
}
</style>
<?php } ?>


<div id="main-content extracls">

<?php if ( ! $is_page_builder_used ) : ?>

	<div class="container">
		<div id="content-area" class="clearfix">
			<div id="left-area">

<?php endif; ?>

			<?php while ( have_posts() ) : the_post(); ?>

				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

				<?php if ( ! $is_page_builder_used ) : ?>

					<h1 class="entry-title main_title"><?php the_title(); ?></h1>
				<?php
					$thumb = '';

					$width = (int) apply_filters( 'et_pb_index_blog_image_width', 1080 );

					$height = (int) apply_filters( 'et_pb_index_blog_image_height', 675 );
					$classtext = 'et_featured_image';
					$titletext = get_the_title();
					$thumbnail = get_thumbnail( $width, $height, $classtext, $titletext, $titletext, false, 'Blogimage' );
					$thumb = $thumbnail["thumb"];

					if ( 'on' === et_get_option( 'divi_page_thumbnails', 'false' ) && '' !== $thumb )
						print_thumbnail( $thumb, $thumbnail["use_timthumb"], $titletext, $width, $height );
				?>

				<?php endif; ?>

					<div class="entry-content">
					<?php
						the_content();

						if ( ! $is_page_builder_used )
							wp_link_pages( array( 'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'Divi' ), 'after' => '</div>' ) );
					?>
					</div> <!-- .entry-content -->

				<?php
					if ( ! $is_page_builder_used && comments_open() && 'on' === et_get_option( 'divi_show_pagescomments', 'false' ) ) comments_template( '', true );
				?>

				</article> <!-- .et_pb_post -->

			<?php endwhile; ?>

<?php if ( ! $is_page_builder_used ) : ?>

			</div> <!-- #left-area -->

			<?php get_sidebar(); ?>
		</div> <!-- #content-area -->
	</div> <!-- .container -->

<?php endif; ?>

</div> <!-- #main-content -->

<?php get_footer(); ?>