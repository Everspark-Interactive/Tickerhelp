<?php   if ( 'on' == et_get_option( 'divi_back_to_top', 'false' ) ) : ?>

	<span class="et_pb_scroll_top et-pb-icon"></span>

<?php endif;
?>

<!-- ADDED BY DEEPAK KUMAR -->
<?php if ( is_post_type_archive() || is_home() ) { ?>
<div class="et_pb_section testimonials_bottom_slider why_choose_us et_pb_section_footer et_pb_with_background et_section_regular">
  <div class="heading_center et_pb_row et_pb_row_5">
    <div class="et_pb_column et_pb_column_4_4  et_pb_column_9">
      <div class="et_pb_text et_pb_module et_pb_bg_layout_light et_pb_text_align_left  et_pb_text_5">
        <div class="et_pb_text_inner">
          <h2>Testimonials</h2>         
          <?php echo do_shortcode('[sp_testimonials_slider slides_column="2" slides_scroll="2" speed="3000"]'); ?>
        </div>
      </div>
      <!-- .et_pb_text -->
    </div>
    <!-- .et_pb_column -->
  </div>
  <!-- .et_pb_row -->
</div>
<?php } ?>
<!-- ADDED BY DEEPAK KUMAR -->

<?php
if ( ! is_page_template( 'page-template-blank.php' ) ) : ?>

			<footer id="main-footer">
				<?php get_sidebar( 'footer' ); ?>


		<?php
			if ( has_nav_menu( 'footer-menu' ) ) : ?>

				<div id="et-footer-nav">
					<div class="container">
						<?php
							wp_nav_menu( array(
								'theme_location' => 'footer-menu',
								'depth'          => '1',
								'menu_class'     => 'bottom-nav',
								'container'      => '',
								'fallback_cb'    => '',
							) );
						?>
					</div>
				</div> <!-- #et-footer-nav -->

			<?php endif; ?>
								<p style="color:#a6a6a6; padding-left:70px; display:block; padding-right:10px">Please note that our website is an Attorney Advertisement. We do not recommend that anyone substitute anything they read or learn on the internet for personal legal advice from competent legal counsel. </p>
				<br/>
				<div id="footer-bottom">
					<div class="container clearfix">
                    	<div class="address_info">
			
							<p>Feifer &amp; Greenberg, LLP, 15 Maiden Lane, Suite 1208, New York, NY 10038, (888) 842-5384</p>
                        </div>
                        <div class="site_by">
							<p><span>&copy; <?php echo date('Y'); ?> <span>|</span> <a href="https://www.tickethelp.com/privacy-policy/">Privacy Policy</a></p>
                        </div>
					</div>	<!-- .container -->
				</div>
			</footer> <!-- #main-footer -->
		</div> <!-- #et-main-area -->

<?php endif; // ! is_page_template( 'page-template-blank.php' ) ?>

	</div> <!-- #page-container -->

	<?php wp_footer(); ?>


<?php if(is_page('4952') || is_page('5019') || is_page('5021') || is_page('5023')){ ?>
	<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 969792266;
var google_conversion_label = "gXKSCN7GvQgQira3zgM";
var google_remarketing_only = false;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>

<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//www.googleadservices.com/pagead/conversion/969792266/?label=gXKSCN7GvQgQira3zgM&amp;guid=ON&amp;script=0"/>
	
	<?php } ?>

<script type="text/javascript" src="https://www.tickethelp.com/wp-content/themes/Divi/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://www.tickethelp.com/wp-content/themes/Divi/js/owl.carousel.js"></script>    
 <script type="text/javascript">
	jQuery(document).ready(function() {
    jQuery(".collaps p").hide(), jQuery(document).on("click", ".collaps h4", function() {
        jQuery(this).hasClass("active") ? (jQuery(this).parents(".faqs-service-left").find("h4").removeClass("active"), jQuery(this).parents(".faqs-service-left").find("p").css("display", "none"), jQuery(this).next("p").slideUp(), jQuery(this).removeClass("active")) : (jQuery(this).parents(".faqs-service-left").find("h4").removeClass("active"), jQuery(this).parents(".faqs-service-left").find("p").css("display", "none"), jQuery(this).next("p").slideDown(), jQuery(this).addClass("active"))
    })
});
</script>
	<div class="g-recaptcha" data-sitekey="6LdeWX0UAAAAADnwKG9DrWRoxRLyFFatnEh03S4e"></div>
   
    <?php  if( !wp_is_mobile()){ ?>
         <script>
            jQuery(window).on("scroll", function() {
        	 if (jQuery(this).scrollTop() > 950) { // this refers to window
            
               jQuery("#scroll-frm").css({"position":"fixed","width":"347px","top":"135px","float":"right","z-index":"9"});
              
               jQuery("#scroll-frm").find('#gform_fields_2').find('li').css({"padding-right":"1px"});
                jQuery("#scroll-frm").addClass("scrl-nfrm"); 
                jQuery("#scroll-frm1").removeClass("wout-scrl-nfrm");
               var scrollBottom = jQuery(window).scrollTop() + jQuery(window).height();
               if (scrollBottom > 3500) {
				   console.log(scrollBottom);
                  //jQuery("#scroll-frm").css({"z-index":"-1"});
                  jQuery("#scroll-frm").css({"position":"absolute","width":"100%","top":"142em"});
               }
              }
              if (jQuery(this).scrollTop() < 500) { // this refers to window
                   jQuery("#scroll-frm").css({"position":"unset","width":"auto","top":"auto","float":"none"});
                   jQuery("#scroll-frm").removeClass("scrl-nfrm");
                   jQuery("#scroll-frm1").addClass("wout-scrl-nfrm");
                   jQuery("#scroll-frm").find('#gform_fields_2').find('li').css({"padding-right":"16px"});
                   }
        	  });
         </script>
	<script>
            jQuery(window).on("scroll", function() {
        	 if (jQuery(this).scrollTop() > 950) { // this refers to window
            
               jQuery("#scroll_frm_ped").css({"position":"fixed","width":"347px","top":"135px","float":"right","z-index":"9"});
              
               jQuery("#scroll_frm_ped").find('#gform_fields_2').find('li').css({"padding-right":"1px"});
                jQuery("#scroll_frm_ped").addClass("scrl-nfrm"); 
                jQuery("#scroll_frm1_ped").removeClass("wout-scrl-nfrm");
               var scrollBottom = jQuery(window).scrollTop() + jQuery(window).height();
               if (scrollBottom > 3500) {
				   console.log(scrollBottom);
                  //jQuery("#scroll-frm").css({"z-index":"-1"});
                  jQuery("#scroll_frm_ped").css({"position":"absolute","width":"100%","top":"152em"});
               }
              }
              if (jQuery(this).scrollTop() < 500) { // this refers to window
                   jQuery("#scroll_frm_ped").css({"position":"unset","width":"auto","top":"auto","float":"none"});
                   jQuery("#scroll_frm_ped").removeClass("scrl-nfrm");
                   jQuery("#scroll_frm1_yield").addClass("wout-scrl-nfrm");
                   jQuery("#scroll_frm_ped").find('#gform_fields_2').find('li').css({"padding-right":"16px"});
                   }
        	  });
         </script>
	<script>
            jQuery(window).on("scroll", function() {
        	 if (jQuery(this).scrollTop() > 950) { // this refers to window
            
               jQuery("#scroll_frm_yield").css({"position":"fixed","width":"347px","top":"135px","float":"right","z-index":"9"});
              
               jQuery("#scroll_frm_yield").find('#gform_fields_2').find('li').css({"padding-right":"1px"});
                jQuery("#scroll_frm_yield").addClass("scrl-nfrm"); 
                jQuery("#scroll_frm1_yield").removeClass("wout-scrl-nfrm");
               var scrollBottom = jQuery(window).scrollTop() + jQuery(window).height();
               if (scrollBottom > 3500) {
				   console.log(scrollBottom);
                  //jQuery("#scroll-frm").css({"z-index":"-1"});
                  jQuery("#scroll_frm_yield").css({"position":"absolute","width":"100%","top":"132em"});
               }
              }
              if (jQuery(this).scrollTop() < 500) { // this refers to window
                   jQuery("#scroll_frm_yield").css({"position":"unset","width":"auto","top":"auto","float":"none"});
                   jQuery("#scroll_frm_yield").removeClass("scrl-nfrm");
                   jQuery("#scroll_frm1_yield").addClass("wout-scrl-nfrm");
                   jQuery("#scroll_frm_yield").find('#gform_fields_2').find('li').css({"padding-right":"16px"});
                   }
        	  });
         </script>
    <?php }  ?>
      <?php  if( is_page(6019)){ ?>
    <script>
    jQuery(function($){
        $('.et_pb_accordion .et_pb_toggle_open').addClass('et_pb_toggle_close').removeClass('et_pb_toggle_open');
    
        $('.et_pb_accordion .et_pb_toggle').click(function() {
          $this = $(this);
          setTimeout(function(){
             $this.closest('.et_pb_accordion').removeClass('et_pb_accordion_toggling');
          },700);
        });
    });
</script>
<?php }  ?>
</body>
</html>