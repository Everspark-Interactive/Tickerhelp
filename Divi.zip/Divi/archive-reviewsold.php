<?php get_header();  ?>

<div id="main-content">
	<div class="container">
		<div id="content-area" class="clearfix">
			<div id="left-area">
		<?php
			if ( have_posts() ) :
				while ( have_posts() ) : the_post();
					$post_format = et_pb_post_format();
					// GET FIELD VAL
					$rating = get_post_meta(get_the_ID(), 'rating', true);			
		?>

					<div id="post-<?php the_ID(); ?>" class="reviews_list">
                    	<ul class="star_review_company_logo">
                        	<li>
                            	<?php if ( has_post_thumbnail() ) : ?>
                                        <?php the_post_thumbnail( 'full' ); ?>
                                <?php endif; ?>
                            </li>
                            <li>
                                <ul class="rating_star">
                                    <?php for ($x = 1; $x <= $rating; $x++) { ?>
                                        <li>
                                        	<img src="<?php echo get_template_directory_uri(); ?>/images/reviews_star_yellow.jpg" width="14" height="14" />
                                        </li>
									<?php }	?>
                                </ul>
                            </li>
                        </ul>
                        <?php the_content(); ?>
                    	<h2 class="entry-title"><?php the_title(); ?></h2>
                        <p><?php echo get_the_date(); ?></p>
					</div> <!-- .link_glossary -->
			<?php	
					endwhile;

					if ( function_exists( 'wp_pagenavi' ) )
						wp_pagenavi();
					else
						get_template_part( 'includes/navigation', 'index' );
				else :
					get_template_part( 'includes/no-results', 'index' );
				endif;
			?>
			</div> <!-- #left-area -->
            
		</div> <!-- #content-area -->
	</div> <!-- .container -->
</div> <!-- #main-content -->

<?php get_footer(); ?>