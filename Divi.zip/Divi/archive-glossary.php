<?php get_header(); ?>

<div id="main-content" class="blog_post_layout">
	<div class="container">
		<div id="content-area" class="content-glossary clearfix">
			<div id="left-area">
		<?php
        
        $query_args_banner = array(
          'post_type' => 'glossary',
          'post_status' => 'publish',
          'orderby' => 'menu_order',
          'order' => 'ASC',
          'posts_per_page' => -1
        );
        
        $slides = new WP_Query($query_args_banner);
			if ( $slides->have_posts() ) :
				$count = 1;
				while ( $slides->have_posts() ) : $slides->the_post();
					$post_format = et_pb_post_format();
                     ?>
					<div id="post-<?php the_ID(); ?>" class="link_glossary">
                    	<h2 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                        <span class="number">
                        	<a href="<?php the_permalink(); ?>">
								<?php if ( $count < 100 ) { 
										echo '0' . $count;
							           }
									  else {  
										echo $count;
									  }
								?>
                            </a>
                       	</span>
					</div> <!-- .link_glossary -->
			<?php	$count++;
					endwhile;

					if ( function_exists( 'wp_pagenavi' ) ){
						//wp_pagenavi();
                        }
					else{
						get_template_part( 'includes/navigation', 'index' );}
				else :
					get_template_part( 'includes/no-results', 'index' );
				endif;
			?>
			
			   </div> <!-- #left-area -->
               <div class="glosry-sidbr">
                <?php get_sidebar(); ?>
               </div>
			
		</div> <!-- #content-area -->
	</div> <!-- .container -->
</div> <!-- #main-content -->

<?php get_footer(); ?>