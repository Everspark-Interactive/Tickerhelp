<?php get_header(); ?>

<div id="main-content" class="blog_post_layout">
	<div class="container">
		<div id="content-area" class="clearfix">
			<div id="left-area">
		<?php
			if ( have_posts() ) :
				while ( have_posts() ) : the_post();
					$post_format = et_pb_post_format(); ?>

					<article id="post-<?php the_ID(); ?>" <?php post_class( 'et_pb_post' ); ?>>

                        <div class="featured_image">
                            <?php if ( has_post_thumbnail() ) : ?>
                                <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                                    <?php the_post_thumbnail('custom-size', 220, 180 ); ?>
                                </a>
                            <?php endif; ?>
                            <div class="date_month"><?php echo get_the_date( 'd' ); ?> <span><?php echo get_the_date( 'M' ); ?></span> <span><?php echo get_the_date( 'Y' ); ?></span></div>
                        </div>
						
                        <div class="post_content_area">
                            <h1 class="entry-title"><br/><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
                            <ul class="post_meta_items">
                            	<li>
                                	<p class="post_time">by <span><?php echo get_the_author(); ?></span></p>
                                </li>
                                <li>
                                	<p class="post_author_name"><?php echo get_the_time('', $post->ID); ?></p>
                                </li>
                            </ul>                            
                            <?php        
                                if ( 'on' !== et_get_option( 'divi_blog_style', 'false' ) || ( is_search() && ( 'on' === get_post_meta( get_the_ID(), '_et_pb_use_builder', true ) ) ) ) {
                                    truncate_post( 170 );
                                } else {
                                    the_content();
                                }
                            ?>
                            <p><a class="readmore_btn" href="<?php the_permalink(); ?>">Read More</a></p>
                        </div>
						<div class="clearboth"></div>
					</article> <!-- .et_pb_post -->
			<?php
					endwhile;

					if ( function_exists( 'wp_pagenavi' ) )
						wp_pagenavi();
					else
						get_template_part( 'includes/navigation', 'index' );
				else :
					get_template_part( 'includes/no-results', 'index' );
				endif;
			?>
			</div> <!-- #left-area -->

			<div class="glosry-sidbr index">
                <?php get_sidebar(); ?>
               </div>
		</div> <!-- #content-area -->
	</div> <!-- .container -->
</div> <!-- #main-content -->

<?php get_footer(); ?>