<?php 

get_header(); 

$show_default_title = get_post_meta( get_the_ID(), '_et_pb_show_title', true );

$is_page_builder_used = et_pb_is_pagebuilder_used( get_the_ID() );

?>
<style type="text/css">
.mid_contents ul li {
    position: relative !important;
    padding-left: 25px !important;
    list-style-type: none !important;
}
.mid_contents ul li:before {
    content: "\f18e" !important;
    font-family: FontAwesome !important;
    display: inline-block !important;
    margin-left: -1.3em !important;
    width: 1.3em !important;
}
</style>
<div id="main-content" class="blog_post_layout">
	<div class="container">
		<div id="content-area" class="clearfix">
			<div id="left-area">
        <?php

			if ( have_posts() ) :

				while ( have_posts() ) : the_post();

					$post_format = et_pb_post_format(); ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class( 'et_pb_post' ); ?>>
         <div class="post_content_area">
			
            <?php if ( has_post_thumbnail() ) : ?>
            <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
            <?php the_post_thumbnail('large'); ?>
            </a>
            <?php endif; ?>
            <div class="date_month"><?php echo get_the_date( 'd' ); ?> <span><?php echo get_the_date( 'M' ); ?></span><span><?php echo get_the_date( 'Y' ); ?></span></div>

            <h2 class="entry-title"><br/><a href="<?php the_permalink(); ?>">
              <?php the_title(); ?>
              </a></h2>
            <ul class="post_meta_items">
              <li>
                <p class="post_time">by <span><?php echo get_the_author(); ?></span></p>
              </li>
              <li>
                <p class="post_author_name"><?php echo get_the_time('', $post->ID); ?></p>
              </li>
            </ul>
            <div class="mid_contents"><?php the_content(); ?></div>
          </div>
          <div class="clearboth"></div>
        </article>
        <!-- .et_pb_post -->
        <?php

					endwhile;



					if ( function_exists( 'wp_pagenavi' ) )

						wp_pagenavi();

					else

						get_template_part( 'includes/navigation', 'index' );

				else :

					get_template_part( 'includes/no-results', 'index' );

				endif;

			?>
      </div> <!-- #left-area -->

			<div class="glosry-sidbr">
                <?php get_sidebar(); ?>
               </div>
		</div> <!-- #content-area -->
	</div> <!-- .container -->
</div> <!-- #main-content -->

<?php get_footer(); ?>